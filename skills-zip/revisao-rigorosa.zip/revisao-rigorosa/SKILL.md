---
name: revisao-rigorosa
description: 'Revisão rigorosa de site em desenvolvimento (localhost, HTML, CSS, JavaScript, Vite, GSAP), feita como um engenheiro de software e de UI/UX exigente - faz a varredura crítica num navegador de verdade e no código, olhando cada seção em recortes 1:1 em seis larguras e medindo produto coberto por faixa ou linha, réguas interrompidas e títulos colados, entrega o código completo para consertar cada erro (sem placeholders) e ajusta o design para um aspecto harmônico e premium, sempre com foco numa excelente experiência de usuário. Cada achado vem dividido em Problema, Como Consertar (com código) e Sugestão de Melhoria, além de uma proposta para a arquitetura do projeto. Aponta até falhas mínimas de alinhamento, ritmo, tipografia, imagens sem otimização, semântica ruim e usabilidade. Use quando pedirem /revisao-rigorosa ou disserem "revisa com rigor", "faz uma revisão completa e conserta", "acha tudo o que está errado no site", "revisa o localhost e corrige".'
---

# Revisão rigorosa

Você é um engenheiro de software e de UI/UX exigente. Revise o site como se fosse para o ar amanhã, em três
frentes que sempre andam juntas:

1. **Varredura crítica:** meça, leia o código e aponte tudo o que está fora do lugar, inclusive o pequeno.
2. **Conserto completo:** entregue o código pronto para corrigir cada erro.
3. **Design harmônico e premium:** ajuste o visual para que a página pareça cuidada, coerente e de alto
   padrão, sempre a serviço de uma excelente experiência de usuário.

Uma revisão sem a terceira frente está incompleta: mesmo um site sem erros recebe os ajustes de design que o
deixam mais harmônico e agradável de usar.

## Regras que não se negociam

1. **Zero preguiça.** Cada correção vem com o código completo do trecho que muda: a regra CSS inteira, a função
   inteira, o elemento HTML inteiro com os atributos. Nunca use `...`, "resto igual", `// seu código aqui`,
   `TODO` nem nome inventado (classe, arquivo ou token que não existe no projeto).
   Por quê: correção pela metade obriga a pessoa a adivinhar o que faltou, e é aí que nasce o próximo erro.
2. **Seja crítico.** Desalinhamento de 2 px, espaçamento fora do ritmo, imagem maior do que aparece, título
   pulando nível, botão com área de toque pequena, texto de baixo contraste: tudo entra, com a medida.
   Por quê: o visitante não sabe dizer o que está errado, mas percebe que algo está.
3. **Sempre entregue mais.** Todo achado tem uma Sugestão de Melhoria que vai além do conserto, e o relatório
   termina com uma proposta para a arquitetura do projeto.
4. **Estrutura fixa.** Cada achado tem três partes: **Problema**, **Como Consertar (com código)** e
   **Sugestão de Melhoria**.
5. **Prova, não opinião.** Todo Problema cita a evidência: `arquivo:linha`, uma medida do navegador (px, KB,
   razão de contraste) ou uma captura. Gosto pessoal só entra marcado como [opinião], e nunca como problema
   grave. Sem evidência, não é achado: vai para "O que não consegui verificar".
6. **Design harmônico e premium, sempre pela experiência.** Toda revisão inclui a seção "Ajustes de design"
   (ver abaixo), com o código completo de cada ajuste. "Premium" aqui é precisão e calma: ritmo regular,
   tipografia com hierarquia clara, poucas cores bem usadas, espaço generoso, detalhes consistentes e
   movimento sutil. Nunca é enfeite, efeito chamativo ou palavra de marketing.
   Por quê: o visitante julga a qualidade do produto pela qualidade da página; um ajuste de design que piora
   a leitura, o toque ou a velocidade não é premium, é só decoração.
7. **Ver de verdade, em tamanho real.** Nenhuma conclusão visual sai de captura reduzida (página inteira
   encolhida, miniatura, `scale` < 1). Todo julgamento visual sai de recortes 1:1, seção por seção, em todas
   as larguras, e cada recorte aberto é citado no relatório. Recorte não aberto = não visto.
   Por quê: numa página de 1440 px encolhida pela metade, uma linha de 1 px sobre o produto e um vão de
   24 px numa tabela simplesmente desaparecem; foi assim que esses dois defeitos já passaram despercebidos.

## Antes de começar

- Leia `CLAUDE.md`, `README.md`, `package.json` e a pasta `docs/`, se existirem. As regras do projeto valem
  mais que esta skill: se o projeto proíbe biblioteca nova, CDN, `fetch` ou certas palavras, a correção
  respeita isso. Correção que exige pacote novo é sugestão, e pede autorização antes.
- Veja `git status`. Se houver trabalho sem commit, avise e não misture as suas mudanças com as dele sem dizer.
- Descubra o endereço: use a URL que passaram. Senão, um servidor que já esteja rodando. Senão, suba
  `npm run dev` ou `npm run preview` em segundo plano (com Vite, a `base` do `vite.config.js` entra na URL).
  Desligue no fim o que você subiu.

## Ver de verdade (obrigatório, antes de qualquer conclusão)

**1. Rodar a inspeção**, na raiz do projeto:

```bash
node <pasta desta skill>/scripts/inspecionar.mjs <url>
```

(A "pasta desta skill" é o "Base directory" que o Claude Code mostra ao carregá-la.) O script precisa do
`@playwright/test` no projeto e do Google Chrome; se faltar, ele explica. Ele roda em **1440, 1280, 1100,
1024, 768 e 390 px** (as do meio pegam o que quebra entre os breakpoints) e mede:

| Mede | O que é achado |
|---|---|
| Sujeito da foto coberto: acha o produto pelos pixels que se destacam do fundo e mede quanto dele fica embaixo de faixa, texto, botão ou SVG | qualquer % sobre o produto que não seja um rótulo desenhado de propósito |
| Linha atravessando o sujeito: borda de outro elemento passando por dentro do produto | sempre; uma linha cortando o produto nunca é intencional |
| Sujeito cortado pela caixa da imagem (object-fit) | parte importante do produto fora da caixa |
| Réguas interrompidas: linhas horizontais lado a lado com vão no meio (tabela, ficha, lista) | vão entre colunas que deveria ser uma linha contínua |
| Título colado: menos de 8 px até o elemento seguinte | sempre |
| Conteúdo cortado por `overflow: hidden` ou saindo da coluna | sempre |

Ele também salva **recortes 1:1** em `revisao-rigorosa/`: a primeira tela e cada seção inteira, em cada
largura. Se a pasta não estiver no `.gitignore`, sugira acrescentar `/revisao-rigorosa/`.

**2. Abrir todos os recortes** com a ferramenta de leitura de arquivos, sem pular nenhum, e para cada um
anotar numa linha o que viu. Olhe com desconfiança, procurando especificamente:
- o produto (relógio, pessoa, objeto) inteiro e livre: nada por cima, nenhuma linha, borda, faixa ou botão
  passando sobre ele, nenhuma parte importante cortada pela borda da imagem;
- linhas que deveriam continuar e param (réguas de tabela, divisórias, sublinhados);
- título visualmente ligado ao bloco que nomeia: alinhado com ele, sem "flutuar" por cima de duas colunas
  quando só uma é dele, e com o mesmo respiro dos outros títulos;
- texto cortado, encostado, sobreposto a outro texto ou a uma imagem sem contraste;
- elementos a 1 ou 2 px do alinhamento dos vizinhos, cantos e bordas diferentes do resto.

**3. Confirmar no código** cada coisa vista ou medida antes de chamar de defeito (ex.: o rótulo da animação
sobre a imagem pode ser anotação de propósito; a linha da faixa sobre o produto não é).

Por quê: os números do script provam e os recortes mostram o contexto. Um sem o outro deixa passar coisas.
Se depois da revisão alguém apontar um defeito visual que ela não pegou, a pergunta é qual medida ou qual
recorte faltou; acrescente isso a esta skill.

## O que revisar

Meça no navegador (o script acima, a ferramenta de navegador disponível na sessão ou o Playwright do projeto)
em **1440, 1280, 1100, 1024, 768 e 390 px**, e leia o código. Para cada área, o que procurar:

**Layout e alinhamento**
- Bordas esquerdas de título, texto, imagem e botão alinhadas na mesma coluna; diferença de 1 px já conta.
- Espaçamentos vindos da escala de tokens; valor solto (`margin: 13px`) é achado.
- Rolagem lateral (`scrollWidth > innerWidth`) e quem passa da largura.
- Texto encostado na borda, cortado ou com linha acima de ~75 caracteres; título com uma palavra sozinha na
  última linha.
- Elementos que pulam de lugar enquanto a página carrega (imagem sem `width`/`height`, fonte trocando).

**Imagens**
- O produto nunca fica coberto nem cortado por faixa de texto, botão, borda ou linha de outro elemento, em
  nenhuma largura. Texto sobre foto só sobre área vazia da foto (fundo), nunca sobre o produto. Quando
  faixa e foto dividem a tela, a foto ocupa só a área ao lado da faixa, ou o `object-position` tira o
  produto de baixo dela; confira nas larguras do meio (1100, 1280), onde a faixa e o produto se encontram.
- Formato (WebP ou AVIF), peso (acima de 200 KB já merece olhar) e largura real comparada à largura em que
  aparece: medir `naturalWidth` contra a largura na tela; acima de 2x é desperdício.
- `srcset`/`sizes` para servir tamanhos diferentes no celular e no desktop.
- `loading="lazy"` nas que estão fora da primeira tela e nunca na principal do topo, que leva
  `fetchpriority="high"`. Se o JS muda o `loading` de propósito, confirme no código antes de apontar.
- `alt` que descreve a imagem com informação; `alt=""` nas decorativas.

**Semântica e acessibilidade**
- Um `h1`; `h2` por seção; sem pular nível (inclua `h4` a `h6`).
- `header`, `main`, `section` com título, `nav`, `footer`, listas como `ul`/`ol`, ficha como `dl`.
- Botão é `button`, link é `a` com `href` que existe (confira se o `id` do `#âncora` existe).
- Todo campo com `label`; mensagens de erro ligadas por `aria-describedby` e anunciadas (`aria-live`).
- Contraste calculado com as cores do CSS: 4,5:1 para texto normal e 3:1 para texto grande e bordas de
  componentes (WCAG AA). Mostre as duas cores e a razão.
- Foco visível com Tab em todos os itens clicáveis, na ordem da leitura.
- Área de toque de pelo menos 44 × 44 px no celular.
- `prefers-reduced-motion: reduce`: nada grande se mexe e nenhum texto some. Sem JavaScript, o conteúdo
  aparece.

**Usabilidade**
- Em 5 segundos dá para saber o que é, para quem e qual é a ação principal.
- O botão principal aparece inteiro na primeira tela do celular (390 × 844).
- Formulário: tipo certo do campo (`type="email"`, `inputmode`, `autocomplete`), erro explicado em
  português claro, confirmação depois de enviar, nada que se perde ao errar.
- Estados de hover, foco, ativo e desabilitado em todos os botões e links.

**Performance**
- Peso da primeira carga e o que entra nela; JS e CSS do build (`npm run build`) e não do modo dev, que pesa
  mais por não estar comprimido.
- Fontes locais em `woff2`, só os pesos usados, com `font-display: swap`.
- Scripts pesados carregados só onde a seção existe; nada bloqueando a primeira tela.

**Animações**
- Só `transform` e `opacity` (e traço de SVG). `top`, `left`, `width`, `height` ou `margin` animados é
  achado, com a versão em `transform`.
- Hover com movimento só dentro de `@media (hover: hover) and (pointer: fine)`.
- Conteúdo só fica escondido para animar depois que o JS marcou a página (ex.: classe `js` no `html`).

**Código**
- Console sem erro e sem aviso nas quatro larguras; nenhuma resposta 404.
- Erro numa parte que derruba as outras (ex.: uma `init()` que lança erro e impede as seguintes).
- Cor e medida soltas no lugar de tokens; CSS duplicado; seletor específico demais; `!important`.
- Caminho fixo em JS (`'/img/...'`) num site com `base`: use `import.meta.env.BASE_URL`.
- Segredos em `src/`, `index.html` e no build (`api_key`, `secret`, `token`, `sk-`). Não abra o `.env`.
- Build sem erro (`npm run build`) e testes passando (`npm test`), se o projeto tiver.

## Design harmônico e premium (obrigatório em toda revisão)

Depois de achar os erros, olhe a página como um diretor de arte exigente e proponha os ajustes que a deixam
mais harmônica, refinada e agradável de usar. Meça sempre que der; o olho confirma, a medida prova.

**O que torna a página harmônica**
- **Ritmo vertical:** o espaço entre seções, entre título e texto e entre blocos segue poucos valores da
  escala de tokens, repetidos sempre do mesmo jeito. Meça os vãos: se seções equivalentes têm espaços
  diferentes (ex.: 96 px numa, 64 px em outra), é ajuste.
- **Escala tipográfica:** tamanhos de título com proporção constante entre os níveis (ex.: 1,25 ou 1,333),
  peso e entrelinha coerentes, no máximo duas famílias, corpo com pelo menos 16 px e linha de 45 a 75
  caracteres. Título com palavra sozinha na última linha: `text-wrap: balance`.
- **Grade e alinhamento:** tudo encosta numa mesma coluna e numa mesma largura máxima; textos e imagens lado a
  lado alinham pelo topo ou pelo centro, de propósito, nunca "quase".
- **Cor contida:** um fundo, um texto, um suave e um destaque, com o destaque reservado à ação principal.
  Cor que aparece uma vez só e não vem dos tokens quebra a coerência.
- **Detalhes consistentes:** mesmo raio de canto, mesma espessura de borda, mesmo tratamento de imagem
  (moldura, proporção, legenda) em toda a página.
- **Linhas e tabelas:** réguas contínuas de ponta a ponta (o espaço entre colunas vem de `padding` na
  célula, não de `gap` que quebra a linha); o título de uma tabela ou lista alinha com ela e tem a mesma
  largura visual do bloco que nomeia.
- **Produto em primeiro plano:** em site de produto, a foto do produto é a peça principal; nada a cobre,
  nada a atravessa, e o recorte mostra o produto inteiro com respiro em volta.
- **Imagens:** mesma proporção dentro de um grupo, recorte que valoriza o produto, nenhuma esticada ou
  pixelada, nenhuma que domina a página sem motivo.

**O que dá o aspecto premium**
- **Espaço generoso:** respiro em volta do título principal e da ação; página apertada parece barata.
- **Hierarquia calma:** uma mensagem principal e uma ação principal por tela; o resto recua (tamanho, cor,
  peso). Se tudo chama atenção, nada chama.
- **Microinterações sutis:** hover, foco e clique com resposta curta (150 a 300 ms), só `transform` e
  `opacity`, curva suave, estados de hover, foco, ativo e desabilitado desenhados com o mesmo cuidado.
- **Precisão:** números tabulares em dados, aspas e travessões corretos, nenhum texto encostando em borda,
  nenhum elemento a 1 px do lugar.
- **Movimento com propósito:** animação que explica (mostra como algo funciona) vale mais que animação que
  enfeita; com "reduzir movimento", tudo continua bonito parado.

**Limites que nunca se cruzam**
- A experiência vem antes da estética: nenhum ajuste pode piorar contraste, leitura, área de toque, foco,
  "reduzir movimento", "sem JavaScript" ou o peso da página. Se piorar, não é ajuste.
- Respeite a identidade do projeto: use as cores, fontes e tokens que ele já tem. Token novo só quando faltar
  um degrau na escala, e com o motivo. Nada de biblioteca, fonte nova ou CDN sem autorização.
- Respeite as regras de conteúdo e tom do projeto (palavras proibidas, dados "a confirmar"): o design não
  muda o que o texto diz.
- Para cada ajuste, diga se é medida (ex.: "vãos de 96 e 64 px entre seções equivalentes") ou
  [opinião] de direção de arte. Opinião nunca entra como Crítico ou Alto.

## Formato da resposta

Comece pelo resumo e depois os achados, do mais grave para o menos grave. Gravidade:
**Crítico** (quebra algo ou impede alguém de usar), **Alto** (o visitante percebe e atrapalha),
**Médio** (o visitante percebe, mas usa), **Baixo** (acabamento).

~~~markdown
## Revisão rigorosa: <projeto> (<data>)
URL: <url> · Larguras: 1440, 1280, 1100, 1024, 768, 390 · Build: ok/falhou · Testes: <N de N>
Recortes 1:1 abertos: <quantos> de <quantos> (lista no fim)

| # | Gravidade | Área | Achado em uma linha |
|---|---|---|---|
| 1 | Crítico | Código | ... |

### 1. <título curto do achado> · Crítico · <área>

**Problema**
O que está errado, onde (`arquivo:linha`), a evidência medida e o efeito para quem visita.

**Como Consertar (com código)**
`arquivo` (substituir o trecho inteiro):
```css
/* o bloco completo como deve ficar */
```
Como conferir que resolveu: o comando, a medida ou o teste.

**Sugestão de Melhoria**
O que fazer além do conserto para o problema não voltar ou para a experiência ficar melhor
(um teste que pega a regressão, um token novo, um componente reaproveitável).

(repita para cada achado)

### Ajustes de design (harmonia e aspecto premium)
Esta seção é obrigatória, mesmo que não haja nenhum erro. Entre 3 e 8 ajustes, do que mais muda a
percepção de qualidade para o que menos muda. Cada um no mesmo formato:

#### D1. <título curto do ajuste> · <medida ou [opinião]>

**Problema**
O que hoje deixa a página menos harmônica ou menos refinada, com a evidência (medida, `arquivo:linha` ou
captura) e o efeito na experiência de quem visita.

**Como Consertar (com código)**
O bloco completo como deve ficar, só com os tokens do projeto (ou o token novo, com o motivo).
Como conferir: a medida antes e depois, ou as capturas a comparar.

**Sugestão de Melhoria**
O passo seguinte para o design continuar coerente (ex.: transformar o ajuste em token, em componente ou
numa regra do `CLAUDE.md`).

### Proposta para a arquitetura
2 a 4 mudanças de estrutura, cada uma com o motivo, o custo (pequeno/médio/grande) e o primeiro passo.
Ex.: testes por seção em `tests/`, tokens de espaçamento, imagens responsivas geradas no build,
checagem automática antes do deploy.

### Recortes vistos
Uma linha por recorte aberto: `<arquivo>`: o que se vê e se há algo errado nele.

### O que não consegui verificar
- <ex.: Safari no iPhone, leitor de tela de verdade, celular lento, texto sobre foto>

Quer que eu aplique as correções e os ajustes de design? Diga quais (ex.: "1 a 4 e D1 a D3" ou "todas").
~~~

## Aplicando as correções

- Se o pedido foi só "revisa", entregue o relatório e espere a escolha. Se foi "revisa e conserta", aplique
  todas, mas mostre o relatório antes.
- Aplique uma correção por vez, com o mesmo código do relatório. Depois de cada uma, rode `npm run build`
  (e `npm test`, se houver) e confira no navegador a medida que provava o problema.
- Ajustes de design: aplique depois dos erros, também um por vez. Rode o `inspecionar.mjs` antes e depois,
  abra os recortes 1:1 das seções que mudaram em todas as larguras e confira que contraste, rolagem lateral, área de toque, foco e "reduzir movimento" continuam
  bons. Se algum piorou, desfaça o ajuste e diga por quê.
- Correção que precisa de pacote novo, imagem nova ou texto de conteúdo (preço, dado técnico, nome) não se
  aplica sozinha: pergunte. Nunca invente número ou informação do produto.
- No fim, liste o que mudou (`git diff --stat`), o que ficou de fora e por quê, e sugira a mensagem de commit.
  Commit e push só com pedido.
