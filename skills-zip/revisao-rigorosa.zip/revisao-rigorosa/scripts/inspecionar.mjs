// inspecionar.mjs (parte da skill revisao-rigorosa)
//
// Mede o que o olho perde numa captura reduzida e gera recortes 1:1 de cada seção para olhar de perto.
//   1. Sujeito da foto coberto: acha onde está o produto em cada imagem (pixels que se destacam do fundo)
//      e mede quanto dele fica embaixo de outro elemento (faixa, texto, botão) ou cortado por uma linha.
//   2. Réguas interrompidas: linhas horizontais (só border-top/bottom) que deveriam ser contínuas e têm
//      um vão no meio (ex.: colunas de uma tabela com gap).
//   3. Título colado: título a menos de 8 px do elemento seguinte.
//   4. Texto cortado ou passando do pai: conteúdo maior que a caixa com overflow escondido, ou que sai
//      da coluna onde está.
//   5. Recortes 1:1 de cada seção em cada largura, para a revisão visual (nunca julgar pela página reduzida).
//
// Uso, na raiz do projeto (precisa do @playwright/test no projeto e do Google Chrome):
//   node <pasta desta skill>/scripts/inspecionar.mjs <url> [larguras separadas por vírgula]
// Saída: revisao-rigorosa/ na raiz do projeto (recortes .png e resultado.json).

import { createRequire } from 'node:module'
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const require = createRequire(join(process.cwd(), 'package.json'))
let chromium
try {
  ;({ chromium } = require('@playwright/test'))
} catch {
  console.error(`Não achei o @playwright/test em ${process.cwd()}. Instale no projeto (muda o package.json, peça antes): npm i -D @playwright/test`)
  process.exit(1)
}

const URL_SITE = process.argv[2]
if (!URL_SITE) {
  console.error('Uso: node inspecionar.mjs <url> [1440,1280,1100,1024,768,390]')
  process.exit(1)
}
// Além das larguras clássicas, 1280 e 1100 pegam o que quebra entre os breakpoints
const LARGURAS = (process.argv[3] || '1440,1280,1100,1024,768,390').split(',').map(Number)
const PASTA = join(process.cwd(), 'revisao-rigorosa')
rmSync(PASTA, { recursive: true, force: true })
mkdirSync(PASTA, { recursive: true })

// Roda dentro da página. Uma função só, sem nada de fora (o Playwright copia só o texto dela).
async function inspecionarPagina() {
  const nome = (el) => {
    if (!el || el === document.body) return 'body'
    const id = el.id ? '#' + el.id : ''
    const cls = el.classList?.length ? '.' + [...el.classList].join('.') : ''
    return el.tagName.toLowerCase() + id + cls
  }
  const visivel = (el) => {
    const cs = getComputedStyle(el)
    const r = el.getBoundingClientRect()
    return cs.display !== 'none' && cs.visibility !== 'hidden' && +cs.opacity > 0.05 && r.width > 0 && r.height > 0
  }
  const res = { sujeitoCoberto: [], linhaSobreSujeito: [], reguasInterrompidas: [], tituloColado: [], transbordando: [] }

  // ---------- 1. Sujeito da foto coberto ----------
  for (const img of document.images) {
    if (!visivel(img) || !img.naturalWidth || !img.complete) continue
    img.scrollIntoView({ block: 'center' })
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))
    const caixa = img.getBoundingClientRect()

    // Onde está o produto: pixels que se destacam da cor dos cantos (o fundo da foto)
    const L = 160
    const A = Math.round((L * img.naturalHeight) / img.naturalWidth)
    const tela = document.createElement('canvas')
    tela.width = L
    tela.height = A
    const ctx = tela.getContext('2d', { willReadFrequently: true })
    try {
      ctx.drawImage(img, 0, 0, L, A)
    } catch {
      continue
    }
    let px
    try {
      px = ctx.getImageData(0, 0, L, A).data
    } catch {
      continue
    }
    const cor = (x, y) => {
      const i = (y * L + x) * 4
      return [px[i], px[i + 1], px[i + 2]]
    }
    const cantos = [cor(1, 1), cor(L - 2, 1), cor(1, A - 2), cor(L - 2, A - 2)]
    const fundo = [0, 1, 2].map((k) => cantos.reduce((s, c) => s + c[k], 0) / 4)
    const xs = []
    const ys = []
    for (let y = 0; y < A; y++) {
      for (let x = 0; x < L; x++) {
        const c = cor(x, y)
        const d = Math.hypot(c[0] - fundo[0], c[1] - fundo[1], c[2] - fundo[2])
        if (d > 60) {
          xs.push(x)
          ys.push(y)
        }
      }
    }
    // Foto sem fundo uniforme (ex.: cena inteira): o sujeito é a foto toda e este teste não se aplica
    if (xs.length < L * A * 0.03 || xs.length > L * A * 0.9) continue
    xs.sort((a, b) => a - b)
    ys.sort((a, b) => a - b)
    const pct = (arr, p) => arr[Math.min(arr.length - 1, Math.floor(arr.length * p))]
    const sujeitoImg = { x0: pct(xs, 0.01) / L, x1: pct(xs, 0.99) / L, y0: pct(ys, 0.01) / A, y1: pct(ys, 0.99) / A }

    // Da imagem para a tela, respeitando object-fit e object-position
    const cs = getComputedStyle(img)
    const nw = img.naturalWidth
    const nh = img.naturalHeight
    let escalaX = caixa.width / nw
    let escalaY = caixa.height / nh
    if (cs.objectFit === 'cover') escalaX = escalaY = Math.max(caixa.width / nw, caixa.height / nh)
    if (cs.objectFit === 'contain') escalaX = escalaY = Math.min(caixa.width / nw, caixa.height / nh)
    const [posX, posY] = cs.objectPosition.split(' ').map((v) => (v.endsWith('%') ? parseFloat(v) / 100 : 0.5))
    const desvioX = (caixa.width - nw * escalaX) * posX
    const desvioY = (caixa.height - nh * escalaY) * posY
    const s = {
      left: caixa.left + desvioX + sujeitoImg.x0 * nw * escalaX,
      right: caixa.left + desvioX + sujeitoImg.x1 * nw * escalaX,
      top: caixa.top + desvioY + sujeitoImg.y0 * nh * escalaY,
      bottom: caixa.top + desvioY + sujeitoImg.y1 * nh * escalaY,
    }
    const cortadoPelaCaixa = {
      esquerda: Math.max(0, caixa.left - s.left),
      direita: Math.max(0, s.right - caixa.right),
      topo: Math.max(0, caixa.top - s.top),
      base: Math.max(0, s.bottom - caixa.bottom),
    }
    const visivelS = {
      left: Math.max(s.left, caixa.left, 0),
      right: Math.min(s.right, caixa.right, innerWidth),
      top: Math.max(s.top, caixa.top, 0),
      bottom: Math.min(s.bottom, caixa.bottom, innerHeight),
    }
    if (visivelS.right <= visivelS.left || visivelS.bottom <= visivelS.top) continue

    // Amostra uma grade dentro do sujeito: quem está por cima em cada ponto?
    const N = 24
    let cobertos = 0
    let total = 0
    const quem = {}
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        const x = visivelS.left + ((i + 0.5) * (visivelS.right - visivelS.left)) / N
        const y = visivelS.top + ((j + 0.5) * (visivelS.bottom - visivelS.top)) / N
        const pilha = document.elementsFromPoint(x, y)
        const posImg = pilha.indexOf(img)
        if (posImg < 0) continue
        total++
        // Por cima da imagem e visível de verdade (fundo, borda ou texto); a figura e o figcaption não contam
        const cima = pilha.slice(0, posImg).find((e) => {
          if (e.contains(img)) return false
          const c = getComputedStyle(e)
          const temFundo = !/rgba\(0, 0, 0, 0\)|transparent/.test(c.backgroundColor)
          const temTexto = [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())
          return temFundo || temTexto || e.tagName === 'svg' || e.closest('svg')
        })
        if (cima) {
          cobertos++
          const k = nome(cima.closest('svg') || cima) + (cima.closest('[aria-hidden="true"]') ? ' (aria-hidden: anotação?)' : '')
          quem[k] = (quem[k] || 0) + 1
        }
      }
    }
    const fracao = total ? cobertos / total : 0
    const cortePx = Object.values(cortadoPelaCaixa).reduce((a, b) => a + b, 0)
    if (fracao > 0.01 || cortePx > 2) {
      res.sujeitoCoberto.push({
        imagem: img.getAttribute('src'),
        sujeitoNaTela: Object.fromEntries(Object.entries(s).map(([k, v]) => [k, Math.round(v)])),
        coberto: Math.round(fracao * 100) + '%',
        porQuem: Object.fromEntries(Object.entries(quem).map(([k, v]) => [k, Math.round((v / total) * 100) + '%'])),
        cortadoPelaCaixaPx: Object.fromEntries(Object.entries(cortadoPelaCaixa).map(([k, v]) => [k, Math.round(v)])),
      })
    }

    // Linhas (bordas) de outros elementos que atravessam o sujeito
    for (const el of document.querySelectorAll('body *')) {
      if (el === img || el.contains(img) || img.contains(el) || !visivel(el)) continue
      const c = getComputedStyle(el)
      const r = el.getBoundingClientRect()
      const lados = [
        ['direita', c.borderRightWidth, c.borderRightStyle, r.right, 'v'],
        ['esquerda', c.borderLeftWidth, c.borderLeftStyle, r.left, 'v'],
        ['topo', c.borderTopWidth, c.borderTopStyle, r.top, 'h'],
        ['base', c.borderBottomWidth, c.borderBottomStyle, r.bottom, 'h'],
      ]
      for (const [lado, larg, estilo, pos, eixo] of lados) {
        if (parseFloat(larg) === 0 || estilo === 'none') continue
        const atravessa =
          eixo === 'v'
            ? pos > s.left + 4 && pos < s.right - 4 && r.bottom > s.top && r.top < s.bottom
            : pos > s.top + 4 && pos < s.bottom - 4 && r.right > s.left && r.left < s.right
        if (atravessa) res.linhaSobreSujeito.push(`${nome(el)}: borda da ${lado} (${larg}) passa por dentro do sujeito de ${img.getAttribute('src')} em ${eixo === 'v' ? 'x' : 'y'}=${Math.round(pos)}px`)
      }
    }
  }
  scrollTo(0, 0)

  // ---------- 2. Réguas interrompidas ----------
  // Elementos que são só linha (borda em cima ou embaixo, sem laterais), lado a lado na mesma altura
  const reguas = [...document.querySelectorAll('body *')].filter((el) => {
    if (!visivel(el)) return false
    const c = getComputedStyle(el)
    const h = parseFloat(c.borderTopWidth) > 0 || parseFloat(c.borderBottomWidth) > 0
    const v = parseFloat(c.borderLeftWidth) > 0 || parseFloat(c.borderRightWidth) > 0
    return h && !v
  })
  const porLinha = {}
  for (const el of reguas) {
    const r = el.getBoundingClientRect()
    const c = getComputedStyle(el)
    const y = parseFloat(c.borderTopWidth) > 0 ? r.top : r.bottom
    const k = nome(el.parentElement) + '@' + Math.round(y + scrollY)
    ;(porLinha[k] ??= []).push(r)
  }
  for (const [k, rs] of Object.entries(porLinha)) {
    if (rs.length < 2) continue
    rs.sort((a, b) => a.left - b.left)
    for (let i = 1; i < rs.length; i++) {
      const vao = rs[i].left - rs[i - 1].right
      if (vao > 1 && vao < 96) {
        res.reguasInterrompidas.push(`${k.split('@')[0]} em y=${k.split('@')[1]}px: vão de ${Math.round(vao)}px entre ${Math.round(rs[i - 1].right)} e ${Math.round(rs[i].left)}`)
        break
      }
    }
  }
  // Uma linha por grupo basta como prova; junta as repetidas
  const grupos = {}
  for (const l of res.reguasInterrompidas) {
    const g = l.split(' em y=')[0]
    grupos[g] = grupos[g] ? { ...grupos[g], n: grupos[g].n + 1 } : { primeira: l, n: 1 }
  }
  res.reguasInterrompidas = Object.values(grupos).map((g) => `${g.primeira} (e mais ${g.n - 1} linha(s) iguais)`)

  // ---------- 3. Título colado no que vem depois ----------
  for (const h of document.querySelectorAll('h1,h2,h3,h4,h5,h6')) {
    const prox = h.nextElementSibling
    if (!prox || !visivel(h) || !visivel(prox)) continue
    const vao = prox.getBoundingClientRect().top - h.getBoundingClientRect().bottom
    if (vao < 8 && vao > -2) res.tituloColado.push(`${nome(h)} "${h.textContent.trim()}" → ${nome(prox)}: ${Math.round(vao)}px`)
  }

  // ---------- 4. Conteúdo cortado ou saindo da coluna ----------
  for (const el of document.querySelectorAll('main *, footer *')) {
    if (!visivel(el) || el.tagName === 'IMG' || el.closest('svg')) continue
    const c = getComputedStyle(el)
    if ((c.overflow === 'hidden' || c.overflowX === 'hidden') && el.scrollWidth > el.clientWidth + 1 && el.textContent.trim())
      res.transbordando.push(`${nome(el)}: conteúdo de ${el.scrollWidth}px numa caixa de ${el.clientWidth}px com overflow escondido (texto cortado?)`)
    const pai = el.parentElement
    if (!pai || pai === document.body || getComputedStyle(pai).display === 'contents') continue
    const r = el.getBoundingClientRect()
    const rp = pai.getBoundingClientRect()
    if (r.right > rp.right + 2 && c.position === 'static' && el.textContent.trim())
      res.transbordando.push(`${nome(el)} passa ${Math.round(r.right - rp.right)}px da direita de ${nome(pai)}`)
  }
  return res
}

const navegador = await chromium.launch({ channel: 'chrome' })
const resultado = { url: URL_SITE, larguras: {} }
for (const largura of LARGURAS) {
  const altura = largura <= 430 ? 844 : 900
  const pagina = await navegador.newPage({ viewport: { width: largura, height: altura } })
  await pagina.goto(URL_SITE, { waitUntil: 'networkidle' })
  // Carrega as imagens lazy
  await pagina.evaluate(async () => {
    for (let y = 0; y < document.body.scrollHeight; y += 500) {
      scrollTo(0, y)
      await new Promise((r) => setTimeout(r, 50))
    }
    scrollTo(0, 0)
  })
  await pagina.waitForTimeout(300)
  const r = await pagina.evaluate(inspecionarPagina)

  // Recortes 1:1: a primeira tela e cada seção inteira, sem reduzir
  const recortes = []
  await pagina.evaluate(() => scrollTo(0, 0))
  await pagina.waitForTimeout(200)
  const primeira = `${largura}-0-primeira-tela.png`
  await pagina.screenshot({ path: join(PASTA, primeira) })
  recortes.push(primeira)
  const secoes = await pagina.$$('main > section, body > footer, body > header')
  for (const [i, secao] of secoes.entries()) {
    const id = (await secao.getAttribute('id')) || (await secao.evaluate((e) => e.tagName.toLowerCase()))
    const arquivo = `${largura}-${i + 1}-${id}.png`
    try {
      await secao.scrollIntoViewIfNeeded()
      await pagina.waitForTimeout(250)
      await secao.screenshot({ path: join(PASTA, arquivo) })
      recortes.push(arquivo)
    } catch (e) {
      recortes.push(`${arquivo} (falhou: ${e.message.split('\n')[0]})`)
    }
  }
  r.recortes = recortes
  resultado.larguras[largura] = r
  await pagina.close()

  console.log(`\n======== ${largura} px ========`)
  const bloco = (titulo, itens) => console.log(`${titulo}: ${itens.length ? '\n  - ' + itens.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join('\n  - ') : 'nada'}`)
  bloco('Sujeito da foto coberto ou cortado', r.sujeitoCoberto)
  bloco('Linha atravessando o sujeito da foto', r.linhaSobreSujeito)
  bloco('Réguas interrompidas', r.reguasInterrompidas)
  bloco('Título colado no elemento seguinte', r.tituloColado)
  bloco('Conteúdo cortado ou saindo da coluna', r.transbordando)
  console.log(`Recortes 1:1 (abrir TODOS): ${recortes.join(', ')}`)
}
await navegador.close()
writeFileSync(join(PASTA, 'resultado.json'), JSON.stringify(resultado, null, 2))
console.log(`\nRecortes e resultado.json em: ${PASTA}`)
