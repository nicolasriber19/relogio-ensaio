# Cursor light: a panel that glows where the mouse passes

A quiet, static block (spec sheet, pricing card, feature grid, FAQ) next to scrubbed films reads as a
dead stop. The cursor light gives it a touch of life without motion: a soft light in the accent colour
follows the mouse inside the block, the border lights up near it, and small items (tags, chips, cards)
inside close their outline where the light passes. Proven on the Calibre Norte build (2026-11-02), on
a spec sheet whose six values were all "to be confirmed": the tags are dashed ("not filled yet") and
the light turns the dash solid where it passes.

Use it on **one or two blocks per page**, never on everything: it is a reward for reaching a quiet
section, not a theme. It is not a scroll device and does not count toward the scrub limit.

## 1. Rules

- **Mouse only.** Turn it on with `(hover: hover) and (pointer: fine)`. On touch there is no "passing
  over", and a light stuck where the finger lifted looks like a bug.
- **No JS, no light.** The block must look finished without it: real border, real background. JS adds
  a class (`.x--luz` / `.is-lit`) that switches the layers on.
- **Coordinates per element, relative to it.** Each lit element gets its own `--x`/`--y` in px from
  its own top-left corner. One `pointermove` on the block, one `requestAnimationFrame` per frame at
  most, a loop over the few targets. Never `background-attachment: fixed` (ignored on iOS, breaks
  inside transformed parents).
- **Only opacity transitions.** The layers fade in and out in ~300 ms on `:hover`; the gradient
  position follows the mouse with no transition (a lagging light feels slow, not smooth).
- **Contrast stays legal under the light.** The inner glow is weak (alpha ≤ 0.2 at the centre, fading
  to transparent): measure muted text over the brightest point.
- **Reduced motion:** nothing moves on its own, so it may stay on; if the block also scales or tilts,
  drop that under `prefers-reduced-motion: reduce`.

## 2. Code

```js
// One block, its small items too. Mouse only; without JS the block stays as it is.
export function cursorLight(block, itemSelector) {
  if (!block || !matchMedia('(hover: hover) and (pointer: fine)').matches) return
  const targets = [block, ...block.querySelectorAll(itemSelector)]
  block.classList.add('is-lit')
  let frame = 0
  let last = null
  const draw = () => {
    frame = 0
    for (const el of targets) {
      const r = el.getBoundingClientRect()
      el.style.setProperty('--x', `${(last.clientX - r.left).toFixed(1)}px`)
      el.style.setProperty('--y', `${(last.clientY - r.top).toFixed(1)}px`)
    }
  }
  block.addEventListener('pointermove', (e) => {
    last = e
    if (!frame) frame = requestAnimationFrame(draw)
  })
}
```

```css
/* Two layers on the block: a wide weak glow inside (::before) and a 1 px ring that lights the border
   near the mouse (::after; the mask keeps only the border). Items get the ring and a small glow. */
.is-lit,
.is-lit .item {
  position: relative;
  isolation: isolate; /* so z-index: -1 sits above the element's own background */
}

.is-lit::before,
.is-lit::after,
.is-lit .item::before,
.is-lit .item::after {
  content: '';
  position: absolute;
  border-radius: inherit;
  opacity: 0;
  transition: opacity 300ms var(--ease);
  pointer-events: none;
}

.is-lit::before {
  z-index: -1;
  inset: 0;
  background: radial-gradient(20rem circle at var(--x, 50%) var(--y, 50%),
    rgb(var(--accent-rgb) / 0.2), rgb(var(--accent-rgb) / 0.06) 45%, transparent 75%);
}

.is-lit::after,
.is-lit .item::after {
  inset: -1px; /* sits on the border */
  padding: 1px; /* ring width */
  background: radial-gradient(16rem circle at var(--x, 50%) var(--y, 50%),
    var(--highlight), var(--accent) 25%, transparent 70%);
  -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
  mask-composite: exclude;
}

.is-lit .item::after {
  background: radial-gradient(8rem circle at var(--x, 50%) var(--y, 50%),
    var(--highlight), var(--accent) 30%, transparent 75%);
}

.is-lit .item::before {
  z-index: -1;
  inset: 0;
  background: radial-gradient(6rem circle at var(--x, 50%) var(--y, 50%),
    rgb(var(--accent-rgb) / 0.22), transparent 70%);
}

.is-lit:hover::before,
.is-lit:hover::after,
.is-lit:hover .item::before,
.is-lit:hover .item::after {
  opacity: 1;
}
```

Sizes that worked: block glow 20rem, border ring 16rem, item ring 8rem, item glow 6rem. Smaller than
that and the effect reads as a hover state, not a light; larger and the whole block just brightens.

**Dashed items:** give the items a `1px dashed` border in the muted border colour. The ring is solid,
so where the light passes the dash closes into a line, which reads as "this will be filled". Good for
anything pending or optional.

## 3. Pitfalls

- **Too subtle on the first try.** Alpha 0.1 inside and a plain accent ring were invisible in
  screenshots on a dark surface. Use a bright highlight colour at the centre of the ring (the page's
  focus or highlight token) fading into the accent, and ~0.2 alpha inside.
- **`-webkit-mask` shorthand with `xor` inside is invalid** and silently drops the declaration. Put
  the keyword in `-webkit-mask-composite`, and write the standard `mask` + `mask-composite: exclude`
  after it (Chrome aliases `-webkit-mask` to `mask`, so the order matters).
- **`z-index: -1` vanishes behind the page** without `isolation: isolate` (or another stacking context)
  on the element.
- **`overflow: hidden` on the block clips the ring** at `inset: -1px`; keep the block unclipped or put
  the ring at `inset: 0` and draw it over the real border.

## 4. Verify

With Playwright, at 1440 px: move the mouse to three points of the block with `mouse.move(x, y,
{ steps: 8 })`, wait ~450 ms, screenshot a clip around the block at each; the light must be visible
in all three and sit where the mouse is. Move the mouse out and check the `::after` opacity returns
to 0. Then open the page with `hasTouch: true, isMobile: true` and with `javaScriptEnabled: false`:
the class must not be on the block in either.
