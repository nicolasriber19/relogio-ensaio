# Explode view: the product comes apart under the scroll

A product page's strongest single move: the closed product, already seen in the hero, travels down
into the next act and disassembles in depth as the visitor scrolls, then settles into a clean,
legible exploded view where each part can be named. Proven on the Calibre Norte watch build
(2026-11-01): hero watch → hand-off → scrubbed film → exploded view with steps and a traced label.

Use it when the subject is a physical object with an inside worth showing (watch, camera, headphone,
sneaker sole, pen, engine part) and an exploded-view image of it exists or can be generated. It is a
`scrub` act, so it counts toward the two-scrub limit, and it is almost always the **peak**: give it the
largest span and keep the act before it quiet.

## 1. Assets: two frames, one film

The film is generated from **two stills of the same shoot**, so it starts exactly where the page already
is and ends on a frame that reads as a technical drawing:

- **Start frame:** the hero photo of the closed product (same file the hero shows). This is what makes
  the hand-off from the hero invisible.
- **End frame:** the exploded view, parts in one row along the product's axis, same studio, same light,
  same background colour. Real artwork beats generated; if you must generate it, use the start frame as
  reference and say "same object, same lighting, same background, parts separated along one axis".
- Same aspect ratio and close to the same size for both (the build used 1600 x 904 for both).

Generate an image-to-video clip with **start and end frame** (Kling 3.0 in Higgsfield accepts both; Veo
and Seedance variants differ, check the panel). Settings that worked: 10 s, 1080p, 16:9, multi-shot
**off** (one continuous camera), no audio.

Prompt scaffold (English; models follow it better):

```
Studio product film on pure black, hard side light, <materials and colours>, photographic, no text.
The closed <product> slowly pushes toward the camera, then disassembles in depth: <outer part> lifts
off and flies past the lens, <the visual signature part> follows and fills the frame for a moment,
<the mechanism> drifts forward, <housing parts> separate. Every part then glides back and settles into
a clean horizontal exploded view, left to right: <part 1>, <part 2>, <part 3>, <part 4>, <part 5>.
Smooth continuous motion, no cuts, no camera shake, no added objects, no reflections of people.
```

The "flies past the lens / fills the frame" beat is the peak; name the part that should do it.

### Driving Higgsfield through the browser (Claude in Chrome)

1. The person must be **logged in**; never type their password. If the page shows Login / Sign up, stop
   and ask them to log in.
2. Video → Create Video → change model to the one with Start frame / End frame slots (Kling 3.0,
   preset GENERAL).
3. Upload the frames with the file-upload tool on the two `type=file` inputs (convert WebP to PNG first).
4. **The prompt box arrives filled with a sample prompt** (the build found a cartoon elephant there).
   Click into it, select all, delete, confirm it is empty with `read_page`, then type the prompt in two
   halves (one long `type` call froze the tab). Verify the box contains only your prompt.
5. Read the price on the Generate button and **ask the person before clicking**. Report the cost.
6. Generation takes 2 to 4 minutes. Wait with a background sleep, then read the clip URL from the page's
   `<video>` elements and download it with curl.

### Inspect before using

- Contact sheet: `ffmpeg -i clip.mp4 -vf "fps=1.2,scale=480:-1,tile=4x3" -frames:v 1 sheet.png`.
- Full-size first frame, a middle frame and the last frame. Check: same object throughout, no extra
  parts, no melted geometry, no text. Small gibberish engravings are common; say so in the report.
- Compare the clip's first frame with the hero photo (mean absolute difference under ~3/255 means the
  hand-off will be invisible).

Encode with `scripts/encode.sh` (desktop crf 22, mobile variant) and export the first frame as the
poster WebP. A 10 s 1080p clip landed at 4.3 MB desktop, 2.7 MB mobile.

## 2. The act

Pinned stage, `+=250%` of scroll, scrub ~0.6. The scroll drives a **time value**, not the video
directly: tween a plain object `{ t }` from 0 to the clip duration and, on update, request one animation
frame that sets `video.currentTime` (skip if within 0.01 s). Never set `currentTime` from inside every
scroll event.

Timeline that worked (12 units):

| Units | What happens |
|---|---|
| 0–1 | Silence: the closed product, almost still. Recognition, not dead scroll |
| 1–8 | The film plays under the hand. The section header leaves before the peak (1.5–2.5) |
| 5.5–11 | One step of copy at a time, starting when the mechanism appears in the film; the last stays |
| 8–9.5 | A traced SVG outline draws around the key part on the **last frame**; a label fades in |
| 9.5–11 | Captions and pending-data notes appear; 11–12 hold before release |

Layout of the stage:

- Black section background equal to the film's studio black, so the film edge disappears.
- **Wide screens (min-aspect-ratio 16/10):** the film covers the screen. Narrow the header column so the
  paragraph stops before the product's outline (measure it; the build needed 21rem).
- **4:3 and portrait:** do not cover (cover pushes the subject under the title). Show the full 16:9 band,
  centred, with a top/bottom mask fade. On portrait, start the band **zoomed** to the scale that fits
  half the viewport height (cap ~1.9x) so the product is large while parts fly, and ease back to 1 as
  they align, so no part is cropped at the end. Use the `translate` property for centring and animate
  `scale`/`transform` separately, or the zoom undoes the centring.
- Text sits only where the film is black; a local radial scrim behind each text block, never a
  full-frame overlay.
- The trace SVG uses the clip's pixel size as its viewBox (e.g. `0 0 1916 1080`) and the same
  `object-fit` as the video, so it lands on the part at every width.

Fallbacks: with `prefers-reduced-motion: reduce` or without JavaScript, show the static exploded-view
image with all steps visible, and **download neither the clip nor GSAP** (import GSAP dynamically inside
the motion branch; set the video `src` from JS only). If the clip fails to load in 15 s, keep the static
composition.

iOS: after `loadeddata`, call `play()` then `pause()` once (muted, playsinline) so later `currentTime`
seeks repaint. Verify on a real phone; headless Chrome cannot prove this.

## 3. Signature: the hero product travels into the film

What makes this feel like one object instead of two sections: the product in the hero **does not scroll
away**. A fixed clone of the hero photo slides and scales from the hero's image box to the exact rect of
the film's first frame, then the film takes over on the same frame.

- Clone the hero figure into a `position: fixed` element already sized and placed like the first frame
  (`left/top/width/height` of the stage at pin start, including the portrait zoom).
- A ScrollTrigger from `section top bottom` to `top top`, scrub true, tweens the clone from
  `{ x, y, scale, clipPath: inset(...) }` (the hero photo's on-screen box, accounting for `object-fit:
  cover`) to `{ 0, 0, 1, inset(0) }`. Only `transform` and `clip-path`.
- Visibility handshake: progress 0 → hero photo visible, clone hidden; 0 < p < 1 → clone visible, hero
  photo hidden, film `opacity: 0`; p ≥ 1 → film visible, clone hidden.
- If the hero has live elements (the watch had SVG hands turning at real time), move them to the
  film's first-frame state during the travel (hands advanced forward to the frame's time), so the
  swap does not jump.
- Fade the hero copy out in the first 30% (translateY −48 px and opacity), and bring the act's header in
  only in the last 8% of the travel; earlier, it passes over the product.
- Put that header fade on the **parent** text block, not on the elements the pin timeline also animates:
  two animations writing `opacity` on the same element fight when scrolling back up.
- The hero must share the film's black and lose dividers and boxed panels; its photo edge dissolves into
  the black with a mask (left edge on desktop, bottom edge on mobile). Give the clone the same faded edge
  at p = 0 and fade the mask out during the travel, or the soft edge turns hard on the first frame.
- Align the hero copy and the act header to one column (`--margem-cena`), so the eye reads one scene.

## 4. Verify (in addition to verify.md)

- Scroll to 8 positions inside the act and 7 positions of the travel, at 1440x900, 1366x768,
  1280x800, 1024x768, 768x1024, 390x844 and 375x667, **down and back up**. Log: clip `currentTime`,
  which step is visible, clone/hero/film visibility, and whether any visible text overlaps the central
  60% of the product. Open the 1:1 captures, not a shrunk strip.
- Check the clone's final rect equals the stage's rect at pin start (within 1 px).
- Test the no-JS fallback on the **build** (`vite preview`), never on the dev server: in dev, Vite
  injects CSS through JavaScript, so a no-JS dev page has no CSS at all and looks broken.
- Confirm in the network log that reduced motion and no-JS fetch no `.mp4` and no GSAP chunk.

## Pitfalls the build hit

| Symptom | Cause | Fix |
|---|---|---|
| Generated clip had a cartoon in it | Sample prompt left in Higgsfield's box | Clear and verify the box before typing |
| Title over the dial on a 4:3 laptop | Cover mode on a 4:3 screen | Cover only at 16:10 and wider |
| Product centring lost on phones | Animating `transform` overwrote `translate(-50%,-50%)` | Centre with the `translate` property |
| Header back over the product when scrolling up | Two animations writing the same `opacity` | Fade the parent block instead |
| Paragraph touching the bezel at 1280–1440 | Text column as wide as the rest of the site | Narrower paragraph on wide screens |
| "No-JS layout broken" | Testing on the Vite dev server | Test on the production build |
